package com.cos.soomgyo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cos.soomgyo.model.FindTeacher;

public interface FindTeacherRepository extends JpaRepository<FindTeacher, Integer> {

}
