package com.cos.soomgyo.controller;

import lombok.Data;

@Data
public class RoomForm {
    private String name;
}
