function nextJoin() {
  var container1 = document.getElementById('container1');
  var container2 = document.getElementById('container2');
  var container3 = document.getElementById('container3');

  container1.style.display ="none";

  container3.style.display ="inline";


  
  
}