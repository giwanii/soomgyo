package com.cos.soomgyo.service;

public class MypageService {

}
