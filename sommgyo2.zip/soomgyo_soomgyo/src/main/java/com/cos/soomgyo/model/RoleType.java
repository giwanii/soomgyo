package com.cos.soomgyo.model;

public enum RoleType {
	STUDENT,TEACHER,ADMIN
}
