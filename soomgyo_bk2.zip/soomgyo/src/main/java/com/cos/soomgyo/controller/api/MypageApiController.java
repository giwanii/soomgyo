package com.cos.soomgyo.controller.api;

public class MypageApiController {

}
