package com.cos.soomgyo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cos.soomgyo.model.Community;

public interface CommunityRepository extends JpaRepository<Community, Integer>{

}
